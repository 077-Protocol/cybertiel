# CyberTiel v25-r3.1 — build and checker corrections

Follow-up to the v25-r3 Pi SRI repair, based on public commit `6acfe4624607581223b56163d4617adbe99345f5` of `077-Protocol/cybertiel`. The repair is published as a reviewable patch with its sealed installer ZIP. Target-side installation and runtime qualification remain pending.

The official Pi 1.0.3 installer lock is preserved byte for byte (SHA256 `d2a441d6f2f137a0a7fe2687cda0350e2028e49724776574db337674d2097fe7`). Its eight missing SHA512 SRI values are supplied by a separate pinned manifest. Each official tarball was freshly downloaded and checked against npm registry metadata. A deterministic derived lock changes exactly those eight `integrity` fields; npm ci uses that derived lock with scripts disabled. Original and derived hashes, installed metadata, dependency tree, READY receipts and independent checker pins are enforced.

Package: `2026-10-06.v25-r3.1`. Runtime installer identity: `2026-10-06.v25-r3`, retained so the existing partial installation can resume. Checker: `CT-CHECK-2.9.1`. Generated files, setup script bindings, checker baseline source snapshots and source pins have been updated together. Historical checker baseline identities remain present. Model, llama.cpp, Node base, container restrictions and host gates remain pinned to the parent values.

Download the updated installer from [`releases/v25-r3.1/cybertiel-v25-r3.1.zip`](releases/v25-r3.1/cybertiel-v25-r3.1.zip) and compare its [SHA256](releases/v25-r3.1/cybertiel-v25-r3.1.zip.sha256). The ZIP is the same artifact used for the final sealed-package tests; its contents are preserved unchanged.

**Start with `SERVER_STEPS.txt`.**

This follow-up fixes two target-reported failures. The llama builder now explicitly installs `pkg-config`, required by the pinned OpenBLAS CMake configuration. The checker preserves the verified `modprobe` symlink name when executing it: resolving it to `kmod` changed argv[0] and selected the wrong applet. Both the alias and canonical executable retain root ownership, parent-directory and mode checks. For a partial v25-r3 install, resume directly with this update; do not archive or relabel its managed directories. The original v25-r2 archival helper remains available for the earlier installation state. The archival helper preserves all files and refuses qualified installations, project data, active installers and managed containers. It does not relabel old evidence as a new installation.

Current v25-r3.1 Linux regression results: **351 PASS / 0 FAIL across 16 suites**, including 13 checks for the builder dependency, preserved resume identity and executable-alias trust/dispatch. Reports are under `evidence/v25-r3.1`; original v25-r3 results remain under `evidence/v25-r3`. Actual npm ci and npm ls passed on macOS arm64 with Node 24.21.0/npm 11.19.0. A corrupt SRI was rejected by npm with EINTEGRITY. See `evidence/v25-r3/VALIDATION_SUMMARY.json` and individual reports/logs. The sealed ZIP and follow-up test/configure results are recorded in `evidence/v25-r3.1`.

Ubuntu 24.04 x86_64 deployment, full production image builds, Pi runtime, model inference and Windows execution have not been performed here. The pinned Docker builder configuration reproduced the original missing-PkgConfig failure and passed with the correction. The installer retains its target-side gates and smoke tests. Linux regression execution used an isolated Alpine VM with GNU tools, not a claimed Ubuntu server installation. Older `docs/evidence` files are parent/historical evidence; current results are in `evidence/v25-r3.1`.

No model weights or upstream tarballs are bundled. The unchanged original release assets and npm metadata are included under `upstream` for review. Tarballs can be checked again with `python3 tools/verify_pi_sri.py`, which downloads but never executes dependency code.

Operator details: [usage](docs/USAGE.md), [threat model](docs/THREAT_MODEL.md). This distribution adds no repository-wide license grant.
